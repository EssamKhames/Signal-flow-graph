/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control_assignment.logic;

import java.awt.Point;
import java.util.ArrayList;
import javafx.scene.Group;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.QuadCurve;
import javafx.scene.text.Text;
import javafx.util.Pair;

/**
 *
 * @author elshamey
 */
public class draw {

    //method to draw node using circle
    private Circle drawnode(int x, int y, int r) {
        Circle c = new Circle(x, y, r);
        c.setFill(Color.WHITE);
        c.setStroke(Color.RED);
        return c;

    }

    
    //method to draw edges between two nodes as a straight line
    private Line drawLine(int startx, int starty, int endx, int endy) {
        Line line = new Line(startx, starty, endx, endy);
        line.setFill(Color.BLACK);
        return line;

    }

    
    //method to draw edges between to nodes as a curve
    private QuadCurve drawcurve(double startx, double starty, double controlx, double controly, double endx, double endy) {
        QuadCurve q = new QuadCurve(startx, starty, controlx, controly, endx, endy);
        q.setStroke(Color.BLACK);
        q.setFill(Color.TRANSPARENT);
        return q;

    }

    
    //method to draw the head of arrow to show the direction using triangle
    private Polygon drawArow(double x1, double y1, double x2, double y2, double x3, double y3) {

        Polygon p = new Polygon();
        p.getPoints().addAll(new Double[]{x1, y1, x2, y2, x3, y3});
        p.setFill(Color.BLACK);
        return p;

    }

    
    // method to draw all component of graph using all the above functions
    //and set its positions and adding the weight and nodes name 
    public Group drawGraph(ArrayList<Pair<Integer, Integer>>[] arr) {
        Group g = new Group();
        int top = 0;
        int down = 0;
        int countup = 0;
        int countdown = 0;
        for (int i = 0; i < arr.length; i++) {
            int x1 = 100 + i * 100;
            int y1 = 400;
            g.getChildren().add(drawnode(x1, y1, 25));
            Text t = new Text(String.valueOf(i));
            t.setX((double) x1 - 5.0);
            t.setY((double) y1 + 5.0);
            g.getChildren().add(t);
            for (int j = 0; j < arr[i].size(); j++) {
                int x2 = 100 + arr[i].get(j).getKey() * 100;
                int y2 = 400;
                if (arr[i].get(j).getKey() - i == 1) {
                    g.getChildren().add(drawLine(x1 + 25, y1, x2 - 25, y2));
                    g.getChildren().add(drawArow(x2 - 25, y2, x2 - 10 - 25, y2 - 10, x2 - 10 - 25, y2 + 10));
                    t = new Text(String.valueOf(arr[i].get(j).getValue()));
                    t.setX((double) (x1 + x2) / 2 - 5.0);
                    t.setY((double) y1 - 15 + 5.0);
                    g.getChildren().add(t);
                } else if (arr[i].get(j).getKey() == i) {
                    g.getChildren().add(drawcurve((double) (x1 - 15), (double) (y2 - 25 - 2), (double) ((x1 + x2) / 2), (double) (y1 - 75), (double) (x1 + 15), (double) (y2 - 25 - 2)));
                    g.getChildren().add(drawArow(x1 - 3, y1 - 50 - 10, x1 - 3, y1 - 50 + 10, x1 + 3, y1 - 50));
                    t = new Text(String.valueOf(arr[i].get(j).getValue()));
                    t.setX((double) x1 - 5.0);
                    t.setY((double) y1 - 75 + 5.0);
                    g.getChildren().add(t);
                } else if (Math.abs(arr[i].get(j).getKey() - i) % 2 == 0) {
                    if (arr[i].get(j).getKey() - i > 0) {
                        g.getChildren().add(drawcurve((double) (x1), (double) (y1 - 27), (double) ((x1 + x2) / 2), (double) (y1 - 75 - top), (double) (x2), (double) (y2 - 27)));
                        g.getChildren().add(drawArow(x2, y2 - 27, x2 - 10, y2 - 27 + 3, x2 - 3, y2 - 27 - 10));
                        t = new Text(String.valueOf(arr[i].get(j).getValue()));
                        t.setX((double) (x1 + x2) / 2 - 5.0);
                        t.setY((double) y1 - 75-countup  + 5.0);
                        g.getChildren().add(t);
                    } else {
                        g.getChildren().add(drawcurve((double) (x1), (double) (y1 - 27), (double) ((x1 + x2) / 2), (double) (y1 - 75 - top), (double) (x2), (double) (y2 - 27)));
                        g.getChildren().add(drawArow(x2, y2 - 27, x2 + 10, y2 - 27 + 3, x2 + 3, y2 - 27 - 10));
                        t = new Text(String.valueOf(arr[i].get(j).getValue()));
                        t.setX((double) (x1 + x2) / 2 - 5.0);
                        t.setY((double) y1 - 75 - countup  + 5.0);
                        g.getChildren().add(t);
                    }
                    top = top + 70;
                    countup += 10;
                } else if (Math.abs(arr[i].get(j).getKey() - i) % 2 == 1) {
                    if (arr[i].get(j).getKey() - i > 0) {
                        g.getChildren().add(drawcurve((double) (x1), (double) (y1 + 27), (double) ((x1 + x2) / 2), (double) (y1 + 75 + down), (double) (x2), (double) (y2 + 27)));
                        g.getChildren().add(drawArow(x2, y2 + 27, x2 - 10, y2 + 27 - 3, x2 - 3, y2 + 27 + 10));
                        t = new Text(String.valueOf(arr[i].get(j).getValue()));
                        t.setX((double) (x1 + x2) / 2 - 5.0);
                        t.setY((double) y1 + 75+ countdown  - 20.0);
                        g.getChildren().add(t);
                    } else {
                        g.getChildren().add(drawcurve((double) (x1), (double) (y1 + 27), (double) ((x1 + x2) / 2), (double) (y1 + 75 + down), (double) (x2), (double) (y2 + 27)));
                        g.getChildren().add(drawArow(x2, y2 + 27, x2 + 10, y2 + 27 - 3, x2 -4, y2 + 27 + 10));
                        t = new Text(String.valueOf(arr[i].get(j).getValue()));
                        t.setX((double) (x1 + x2) / 2 - 5.0);
                        t.setY((double) y1 + 75 + countdown - 20.0);
                        g.getChildren().add(t);
                    }
                    down = down + 70;
                    countdown += 20;
                }
            }
        }

        return g;

    }

}
