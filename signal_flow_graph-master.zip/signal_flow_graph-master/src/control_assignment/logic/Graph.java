package control_assignment.logic;

import java.util.ArrayList;
import java.util.List;
import javafx.util.Pair;

// A directed graph using 
// adjacency list representation 
public class Graph {

    // No. of vertices in graph 
    private int v;
    private int startingNode, endingNode;
    private boolean[] isloopFinished;
    private boolean flag;
    private int[] inFrequency;
    private double numenator = 0;
    private double denominator = 0;
    private double transferFunction = 0;
    private int start = 0;

    // adjacency list  
    private ArrayList<Pair<Integer, Integer>>[] adjList;
    private ArrayList<Pair<String, Integer>> nonTouchingLoopCombination = new ArrayList<>();
    private ArrayList<Pair<String, Integer>> allLoops = new ArrayList<>();
    private ArrayList<Pair<String, Integer>> allPaths = new ArrayList<>();
    private ArrayList<Integer> delta = new ArrayList<>();
    private ArrayList<Integer> pathDelta = new ArrayList<>();

    //Constructor 
    public Graph(int vertices) {

        //initialise vertex count 
        this.v = vertices;

        // initialise adjacency list 
        initAdjList();
    }

    // utility method to initialise 
    // adjacency list 
    @SuppressWarnings("unchecked")
    private void initAdjList() {
        adjList = new ArrayList[v];
        inFrequency = new int[v];
        isloopFinished = new boolean[v];
        for (int i = 0; i < v; i++) {
            adjList[i] = new ArrayList<Pair<Integer, Integer>>();
            inFrequency[i] = 0;
            isloopFinished[i] = false;
        }
    }

    // add edge from u to v 
    public void addEdge(int u, int v, int w) {
        // Add v to u's list. 

        adjList[u].add(new Pair<Integer, Integer>(v, w));
        inFrequency[v]++;
    }
    //define the start and end point for thr forward path 
    public void defineMainNodes(int startingNode, int endingNode) {
        this.startingNode = startingNode;
        this.endingNode = endingNode;
    }

    // Prints all paths from 
    // 's' to 'd' 
    public void EvaluateGraph() {
        printAllPaths(this.startingNode, this.endingNode);
        printAllLoopsInGraph();
        findDeltasAndEvaluateResult();
    }
    //
    private void printAllPaths(int s, int d) {
        boolean[] isVisited = new boolean[v];
        ArrayList<Integer> pathList1 = new ArrayList<>();
        int weight = 1;

        //add source to path[] 
        pathList1.add(s);

        //Call recursive utility 
        printAllPathsUtil(s, d, isVisited, pathList1, weight);
    }

    private void printAllPathsUtil(Integer u, Integer d,
            boolean[] isVisited,
            List<Integer> localPathList, int weight) {

        isVisited[u] = true;
        // Mark the current node 
        if (u.equals(d)) {
            allPaths.add(new Pair<String, Integer>(localPathList.toString(), weight));
            //System.out.println(localPathList);
            // if match found then no need to traverse more till depth 
            isVisited[u] = false;
            return;
        }

        // Recur for all the vertices 
        // adjacent to current vertex 
        for (Pair<Integer, Integer> i : adjList[u]) {

            if (!isVisited[i.getKey()]) {
                // store current node  
                // in path[] 
                localPathList.add(i.getKey());
                printAllPathsUtil(i.getKey(), d, isVisited, localPathList, weight * i.getValue());

                // remove current node 
                // in path[] 
                localPathList.remove(i.getKey());
            }
        }

        // Mark the current node 
        isVisited[u] = false;
    }

    //method to print all loop for all nodes
    private void printAllLoopsInGraph() {
        for (int i = 0; i < v; i++) {
            flag = false;
            if (i == startingNode && inFrequency[i] >= 1) {
                printAllloops(i, i);
            } else if (inFrequency[i] >= 2) {
                printAllloops(i, i);
            }
            isloopFinished[i] = true;
        }
        //try all combinations between loops
        //if combination is formed check for
        //the next combination of bigger size
        int combinationSize = 1;
        while (true) {
            ArrayList<Pair<String, Integer>> combination = new ArrayList<>();
            ArrayList<Pair<String, Integer>> step = new ArrayList<>();
            //System.out.println("Making combinations of size "+ combinationSize);
            nontouching(combination, combinationSize, 0, step);
            if (!combination.isEmpty()) {
                combinationSize++;
                for (int i = 0; i < combination.size(); i++) {
                    nonTouchingLoopCombination.add(combination.get(i));
                }
            } else {
                break;
            }
        }
        denominator = 1;
        for (int i = 0; i < nonTouchingLoopCombination.size(); i++) {
            denominator += (double) nonTouchingLoopCombination.get(i).getValue();
        }

    }

    private void printAllloops(int s, int d) {
        boolean[] isVisited = new boolean[v];
        ArrayList<Integer> pathList2 = new ArrayList<>();
        int weight = 1;
        //add source to path[] 
        pathList2.add(s);

        //Call recursive utility 
        printAllloopsUtil(s, d, isVisited, pathList2, weight);
    }

    private void printAllloopsUtil(Integer u, Integer d,
            boolean[] isVisited,
            List<Integer> localPathList, int weight) {

        // Mark the current node 
        //flag : not to enter this if statement at first time 
        if (u.equals(d) && flag == true) {
            allLoops.add(new Pair<String, Integer>(localPathList.toString(), weight));
            //System.out.println(localPathList);
            // if match found then no need to traverse more till depth 
            isVisited[u] = false;
            return;
        }

        // this if to prevent node to be visited so we can 
        // reach it again
        if (flag == true) {
            isVisited[u] = true;
        }

        // Recur for all the vertices 
        // adjacent to current vertex 
        for (Pair<Integer, Integer> i : adjList[u]) {
            flag = true;

            if (!isVisited[i.getKey()] && !isloopFinished[i.getKey()]) {
                // store current node  
                // in path[] 
                localPathList.add(i.getKey());

                //start: increasing and decreasing when add node and remove it 
                // from path and use it as an index to remove the last node
                start++;
                printAllloopsUtil(i.getKey(), d, isVisited, localPathList, weight * i.getValue());

                // remove current node 
                // in path[] 
                localPathList.remove(start);
                start--;
            }
        }

        // Mark the current node 
        isVisited[u] = false;
    }

    //get all sizes of combination between non-touching loops
    private void nontouching(ArrayList<Pair<String, Integer>> combination,
            int combSize, int index, ArrayList<Pair<String, Integer>> steps) {
        if (steps.size() == combSize) {
            //nested for loop check that there is no intersecton between loops
            for (int i = 0; i < steps.size(); i++) {
                String loopOne = steps.get(i).getKey();
                for (int j = i + 1; j < steps.size(); j++) {
                    String loopTwo = steps.get(j).getKey();
                    for (int k = 0; k < loopOne.length(); k++) {
                        if (loopOne.charAt(k) == '[' || loopOne.charAt(k) == ']'
                                || loopOne.charAt(k) == ','
                                || loopOne.charAt(k) == ' ' || loopOne.charAt(k) == '-') {
                            continue;
                        } else if (loopTwo.indexOf(loopOne.charAt(k)) >= 0) {
//                            System.out.println("failed");
//                            System.out.println("##########");
                            return;
                        }
                    }
                }
            }
            int nonTouchingloopsValue = 1;
            String nonTouchingloopsPath = "";
            for (int i = 0; i < steps.size(); i++) {
                nonTouchingloopsValue *= steps.get(i).getValue();
                nonTouchingloopsPath += steps.get(i).getKey();
                if (i != steps.size() - 1) {
                    nonTouchingloopsPath += "/";
                }
            }
            //if size of combination is odd multiply it by -1
            if (combSize % 2 == 1) {
                nonTouchingloopsValue *= -1;
            }
//            System.out.println("succeeded");
//              System.out.println("##########");
            combination.add(new Pair<String, Integer>(nonTouchingloopsPath, nonTouchingloopsValue));
            return;
        }
        for (int i = index; i < allLoops.size(); i++) {
            steps.add(allLoops.get(i));
            nontouching(combination, combSize, i + 1, steps);
            steps.remove(steps.size() - 1);
        }
    }
//evaluate delta for each paath
    //evaluate the multiplication of the path and its delta weight
    private void findDeltasAndEvaluateResult() {
        for (int i = 0; i < allPaths.size(); i++) {
            String path = allPaths.get(i).getKey();
            ArrayList<Pair<String, Integer>> loopNonTouchingPathCombination = new ArrayList<>();
            for (int j = 0; j < nonTouchingLoopCombination.size(); j++) {
                boolean touched = false;
                String cycle = nonTouchingLoopCombination.get(j).getKey();
                //remove the combinations of loops (individualy and non-touching 
                //that touched the current path
                for (int k = 0; k < path.length(); k++) {
                    if (path.charAt(k) == '[' || path.charAt(k) == ']'
                            || path.charAt(k) == ','
                            || path.charAt(k) == ' ' || path.charAt(k) == '-') {
                        continue;
                    } else if (cycle.indexOf(path.charAt(k)) != -1) {
                        touched = true;
                        break;
                    }
                }
                if (!touched) {
                    loopNonTouchingPathCombination.add(nonTouchingLoopCombination.get(j));
                }
            }
            int pathValue = allPaths.get(i).getValue();
            int deltavalue = 1;
            //calculate the delta of the path
            for (int l = 0; l < loopNonTouchingPathCombination.size(); l++) {
                deltavalue += (loopNonTouchingPathCombination.get(l).getValue());
            }
            delta.add(deltavalue);
            pathDelta.add(pathValue * deltavalue);

        }
        for (int i = 0; i < pathDelta.size(); i++) {
            numenator += (double) pathDelta.get(i);
            //System.out.println(deltas[i]);
        }
        transferFunction = numenator / denominator;
    }

    public String getAllLoops() {
        String loop = "Individual loops : \n";
        int counter = 1;
        for (Pair<String, Integer> i : allLoops) {
            loop += ("L" + counter + " : " + i.getKey() + "   the value:" + i.getValue() + "\n");
            counter++;
        }
        return loop;
    }

    public String getAllPaths() {
        String path = "Forward paths : \n";
        int counter = 1;
        for (Pair<String, Integer> i : allPaths) {
            path += ("M" + counter + " : " + i.getKey() + "   the value:" + i.getValue() + "\n");
            counter++;
        }
        return path;
    }

    public int getStartingNode() {
        return startingNode;
    }

    public int getEndingNode() {
        return endingNode;
    }

    public double getNumenator() {
        return numenator;
    }

    public double getDenominator() {
        return denominator;
    }

    public double getTransferFunction() {
        return transferFunction;
    }

    public String getNonTouchingLoopCombination() {
        ArrayList<Pair<String, Integer>> nonTouchingToPrint = new ArrayList<>();
        for (int i = 0; i < nonTouchingLoopCombination.size(); i++) {
            String nonTouchingCombination = nonTouchingLoopCombination.get(i).getKey();
            boolean found = false;
            for (int j = 0; j < allLoops.size(); j++) {
                if (nonTouchingCombination.equals(allLoops.get(j).getKey())) {
                    found = true;
                    break;
                }
            }
            if (!found) {
                nonTouchingToPrint.add(nonTouchingLoopCombination.get(i));
            }
        }
        String nonTouchingLoopsCombination = "non touching loops combination : \n";
        int counter = 1;
        for (Pair<String, Integer> i : nonTouchingToPrint) {
            nonTouchingLoopsCombination += ("C" + counter + " : " + i.getKey() + "   the value:" + i.getValue() + "\n");
            counter++;
        }
        return nonTouchingLoopsCombination;
    }

    public String getPathDelta() {
        String pathAndDelta = "Multiplication of path's weight and its delta : \n";
        int counter = 1;
        for (Integer i : pathDelta) {
            pathAndDelta += ("Path and delta " + counter + " equals: " + i + "\n");
            counter++;
        }
        return pathAndDelta;
    }

    public ArrayList<Pair<Integer, Integer>>[] getAdjList() {
        return adjList;
    }

    public String getDelta() {
        String Delta = "Delta of paths : \n";
        Delta += "Total delta of the system equals " + denominator + "\n";
        int counter = 1;
        for (Integer i : delta) {
            Delta += ("Delta " + counter + " equals: " + i + "\n");
            counter++;
        }
        return Delta;
    }

}
