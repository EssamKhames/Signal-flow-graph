/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control_assignment.controllers;

import control_assignment.logic.Graph;
import control_assignment.logic.draw;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author elshamey
 */
public class FirstController implements Initializable {
    
    @FXML
    private TextField numofnodes;

    @FXML
    private TextField from;

    @FXML
    private TextField to;

    @FXML
    private TextField weight;

    @FXML
    private TextField startnode;

    @FXML
    private TextField endnode;

    @FXML
    private Button setnumofnodes;

    @FXML
    private Button addedge;

    @FXML
    private Button showresult;
    @FXML
    private Button showgraph;

    @FXML
    private Button setpoints;
    
    @FXML
    private TextArea fb;
    
    @FXML
    private TextArea il;
        
    @FXML
    private TextArea ntl;
            
    @FXML
    private TextArea d;
    
    
    @FXML
    private TextArea tf;
    private boolean in = false;
    private boolean evaluate = true;
    private Graph g;

    
    
    @FXML
    public void setNum() {
        try {
            g = new Graph(Integer.parseInt(numofnodes.getText()));
            in = true;
            numofnodes.setVisible(false);
            setnumofnodes.setVisible(false);
        } catch (Exception e) {
            //add label
        }

    }

    @FXML
    public void insertEdge() {
        if (in) {
            try {
                g.addEdge(Integer.parseInt(from.getText()), Integer.parseInt(to.getText()), Integer.parseInt(weight.getText()));
                to.setText("");
                from.setText("");
                weight.setText("");
            } catch (Exception e) {
                //add label
            }
        }

    }

    @FXML
    public void setDirection() {
        if (in) {
            try {
                g.defineMainNodes(Integer.parseInt(startnode.getText()), Integer.parseInt(endnode.getText()));
                to.setVisible(false);
                from.setVisible(false);
                weight.setVisible(false);
                addedge.setVisible(false);
                startnode.setVisible(false);
                endnode.setVisible(false);
                setpoints.setVisible(false);
            } catch (Exception e) {
                //add label
            }
        }

    }
    
    @FXML
    public void calculate(){
        if(evaluate){
        evaluate = false;
        g.EvaluateGraph();
        fb.setText(g.getAllPaths());
        il.setText(g.getAllLoops());
        ntl.setText(g.getNonTouchingLoopCombination());
        d.setText(g.getDelta());
        tf.setText(g.getNumenator() +" / "  + g.getDenominator() +" = " + g.getTransferFunction());
        }
    }
    
    @FXML
    public void graph(){
        draw d = new draw();
        Stage stage = new Stage();
        stage.setTitle("second");
        stage.setScene(new Scene(d.drawGraph(g.getAdjList()),1800,800));
        stage.show();
    }








    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
